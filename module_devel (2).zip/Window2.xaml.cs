﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace module_devel
{
        /// <summary>
        /// Логика взаимодействия для Window2.xaml
        /// </summary>
        public partial class Window2 : Window
        {
                private TextBox textBox;
                private ListBox listBox;

                public Window2()
                {
                        InitializeComponent();
                        textBox = (TextBox)this.FindName("textBox1");
                        listBox = (ListBox)this.FindName("listBox1");
                }

                private void Button_Click(object sender, RoutedEventArgs e)
                {
                        Window4 window4 = new Window4();
                        window4.Show();
                        this.Close();
                }

                private void Button_Click_1(object sender, RoutedEventArgs e)
                {
                        MainWindow MainWindow = new MainWindow();
                        MainWindow.Show();
                        this.Close();
                }

                private void Button_Click_2(object sender, RoutedEventArgs e)
                {
                        Window1 window1 = new Window1();
                        window1.Show();
                        this.Close();
                }

                private void Button_Click_3(object sender, RoutedEventArgs e)
                {
                        Window3 window3 = new Window3();
                        window3.Show();
                        this.Close();
                }

                private void Button_Click_4(object sender, RoutedEventArgs e)
                {
                        Window5 window5 = new Window5();
                        window5.Show();
                        this.Close();
                }

                private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
                {

                }

                private void Button_Click_5(object sender, RoutedEventArgs e)
                {
                        // Получаем строку из TextBox
                        string input = textBox.Text;

                        // Проверяем правильность расстановки скобок
                        int result = CheckBrackets(input);

                        // Отображаем результат в ListBox
                        if (result == 0)
                        {
                                listBox.Items.Add("Скобки расставлены правильно.");
                        }
                        else if (result == -1)
                        {
                                listBox.Items.Add("Не хватает закрывающих скобок.");
                        }
                        else
                        {
                                listBox.Items.Add($"Ошибка в позиции {result}.");
                        }
                }
                private int CheckBrackets(string input)
                {
                        Stack<int> stack = new Stack<int>();

                        for (int i = 0; i < input.Length; i++)
                        {
                                if (input[i] == '(')
                                {
                                        stack.Push(i);
                                }
                                else if (input[i] == ')')
                                {
                                        if (stack.Count == 0)
                                        {
                                                return i + 1;
                                        }
                                        else
                                        {
                                                stack.Pop();
                                        }
                                }
                        }

                        if (stack.Count > 0)
                        {
                                return -1;
                        }
                        else
                        {
                                return 0;
                        }
                }

        }
}
