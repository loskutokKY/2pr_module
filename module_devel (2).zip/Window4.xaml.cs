﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace module_devel
{
    /// <summary>
    /// Логика взаимодействия для Window4.xaml
    /// </summary>
    public partial class Window4 : Window
    {
        private TextBox TextBox;
        private ListBox listBox;
        public Window4()
        {
            InitializeComponent();
            TextBox = (TextBox)this.FindName("textBox1");
            listBox = (ListBox)this.FindName("listBox1");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow MainWindow = new MainWindow();
            MainWindow.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Window2 window2 = new Window2();
            window2.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Window3 window3 = new Window3();
            window3.Show();
            this.Close();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Window5 window5 = new Window5();
            window5.Show();
            this.Close();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            // Получаем количество чисел (N) из TextBox
            int n = TextBox.Text.Split(' ').Count();

            // Создаем список для хранения чисел
            List<int> numbers = new List<int>();

            // Читаем числа из TextBox и добавляем их в список
            for (int i = 0; i < n; i++)
            {
                int num = int.Parse(TextBox.Text.Split(' ')[i]);
                numbers.Add(num);
            }

            // Индексы для максимального по модулю отрицательного и минимального положительного элемента
            int maxNegIndex = -1;
            int minPosIndex = -1;

            // Поиск максимального по модулю отрицательного и минимального положительного элемента
            for (int i = 0; i < numbers.Count; i++)
            {
                if (numbers[i] < 0) // Если это отрицательный элемент
                {
                    if (maxNegIndex == -1 || Math.Abs(numbers[i]) > Math.Abs(numbers[maxNegIndex]))
                    {
                        maxNegIndex = i;
                    }
                }

                if (numbers[i] > 0) // Если это положительный элемент
                {
                    if (minPosIndex == -1 || numbers[i] < numbers[minPosIndex])
                    {
                        minPosIndex = i;
                    }
                }
            }

            // Проверка, что оба элемента найдены для замены
            if (maxNegIndex != -1 && minPosIndex != -1)
            {
                // Вывод на экран перед заменой
                listBox.Items.Add($"Максимальный по модулю отрицательный элемент: {numbers[maxNegIndex]} на позиции: {maxNegIndex}");
                listBox.Items.Add($"Минимальный положительный элемент: {numbers[minPosIndex]} на позиции: {minPosIndex}");

                // Замена местами
                int temp = numbers[maxNegIndex];
                numbers[maxNegIndex] = numbers[minPosIndex];
                numbers[minPosIndex] = temp;

                // Результирующий массив
                string result_str = "";
                foreach (int num in numbers)
                {
                    result_str += num + " ";
                }
                listBox.Items.Add($"Результат: {result_str}");
            }
            else
            {
                listBox.Items.Add("Не удалось найти необходимые элементы для замены.");
            }
        }
        private int[] FindMaxProduct(List<int> numbers)
        {
            // Сортируем числа в порядке убывания
            numbers.Sort((a, b) => b.CompareTo(a));

            // Находим максимальное произведение
            int[] result = new int[3];
            if (numbers.Count >= 3)
            {
                result[0] = numbers[0];
                result[1] = numbers[1];
                result[2] = numbers[2];
            }
            else if (numbers.Count == 2)
            {
                result[0] = numbers[0];
                result[1] = numbers[1];
                result[2] = 1;
            }
            else if (numbers.Count == 1)
            {
                result[0] = numbers[0];
                result[1] = 1;
                result[2] = 1;
            }
            else
            {
                result[0] = 0;
                result[1] = 0;
                result[2] = 0;
            }

            return result;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {


        }
    }
}
