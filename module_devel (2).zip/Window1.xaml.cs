﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace module_devel
{

        public partial class Window1 : Window
        {
                private TextBox textBox;
                private ListBox listBox;

                public Window1()
                {
                        InitializeComponent();
                        textBox = (TextBox)this.FindName("textBox1"); 
                        listBox = (ListBox)this.FindName("listBox1"); 
                }

                private void Button_Click(object sender, RoutedEventArgs e)
                {
                        MainWindow MainWindow = new MainWindow();
                        MainWindow.Show();
                        this.Close();
                }

                private void Button_Click_1(object sender, RoutedEventArgs e)
                {
                        Window2 window2 = new Window2();
                        window2.Show();
                        this.Close();
                }

                private void Button_Click_2(object sender, RoutedEventArgs e)
                {
                        Window3 window3 = new Window3();
                        window3.Show();
                        this.Close();
                }

                private void Button_Click_3(object sender, RoutedEventArgs e)
                {
                        Window4 window4 = new Window4();
                        window4.Show();
                        this.Close();
                }

                private void Button_Click_4(object sender, RoutedEventArgs e)
                {
                        Window5 window5 = new Window5();
                        window5.Show();
                        this.Close();
                }












                private void yearTextBox_TextChanged(object sender, TextChangedEventArgs e)
                {

                }

                private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
                {

                }

                private void Button_Click_5(object sender, RoutedEventArgs e)
                {
                        // Проверяем, что введенный год не пустой
                        if (!string.IsNullOrEmpty(textBox.Text))
                        {
                                // Удаляем пробелы из введенного года
                                string trimmedYear = textBox.Text.Trim();

                                // Проверяем, что введенный год содержит только цифры
                                if (int.TryParse(trimmedYear, out int year))
                                {
                                        // Вычисляем номер столетия
                                        int century = (year + 99) / 100;

                                        // Отображаем результат в ListBox
                                        listBox.Items.Add($"Год {year} относится к {century} столетию.");
                                }
                                else
                                {
                                        // Показываем сообщение об ошибке, если значение в TextBox некорректное
                                        MessageBox.Show("Пожалуйста, введите корректный год. Введите только цифры.");
                                }
                        }
                        else
                        {
                                // Показываем сообщение об ошибке, если текстовое поле пустое
                                MessageBox.Show("Пожалуйста, введите год.");
                        }
                }        
        }
    
}
