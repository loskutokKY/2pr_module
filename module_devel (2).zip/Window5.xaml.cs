﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace module_devel
{
    /// <summary>
    /// Логика взаимодействия для Window5.xaml
    /// </summary>
    public partial class Window5 : Window
    {
        private int m;
        private int n;
        private int[,] array;
        private int min;
        private int max;
        private int[,] sortedArrayAsc;
        private int[,] sortedArrayDesc;

        private TextBox TextBox1;
        private TextBox TextBox2;
        private ListBox listBox1;
        private ListBox listBox2;
        private ListBox listBox3;

        public Window5()
        {
            InitializeComponent();
            // Получаем размеры массива из TextBox
            TextBox1 = (TextBox)this.FindName("___TextBox1_");
            TextBox2 = (TextBox)this.FindName("___TextBox2_");
            listBox1 = (ListBox)this.FindName("___ListBox1_");
            listBox2 = (ListBox)this.FindName("___ListBox2_");
            listBox3 = (ListBox)this.FindName("___ListBox3_");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow MainWindow = new MainWindow();
            MainWindow.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Window3 window3 = new Window3();
            window3.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Window2 window2 = new Window2();
            window2.Show();
            this.Close();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Window4 window4 = new Window4();
            window4.Show();
            this.Close();
        }

        public static int[,] Sort2DArray(int[,] array, bool ascending = true)
        {
            int rows = array.GetLength(0);
            int columns = array.GetLength(1);

            // Представляем как 1D массив
            int[] flatArray = new int[rows * columns];
            int index = 0;

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    flatArray[index++] = array[i, j];
                }
            }

            // Сортируем
            if (ascending)
            {
                Array.Sort(flatArray);
            }
            else
            {
                Array.Sort(flatArray);
                Array.Reverse(flatArray);
            }

            // Укладываем снова в 2D массив
            index = 0;
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    array[i, j] = flatArray[index++];
                }
            }

            return array;
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            // Получаем размеры массива из TextBox
            int m = int.Parse(TextBox1.Text);
            int n = int.Parse(TextBox2.Text);

            // Создаем и заполняем массив случайными числами от -10 до 10
            int[,] array = new int[n, m];
            Random rand = new Random();
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    array[i, j] = rand.Next(-10, 11);
                }
            }

            // Выводим исходный массив в ListBox1
            listBox1.Items.Clear();
            for (int i = 0; i < n; i++)
            {
                string row = "";
                for (int j = 0; j < m; j++)
                {
                    row += array[i, j] + " ";
                }
                listBox1.Items.Add(row);
            }

            // Находим минимальный и максимальный элементы массива
            int min = array[0, 0];
            int max = array[0, 0];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    if (array[i, j] < min)
                        min = array[i, j];
                    if (array[i, j] > max)
                        max = array[i, j];
                }
            }
            listBox1.Items.Add($"Минимальный элемент: {min}, Максимальный элемент: {max}");

            // Сортируем массив по возрастанию и выводим в ListBox3
            listBox3.Items.Clear();
            int[,] sortedArrayAsc = (int[,])array.Clone();
            Sort2DArray(sortedArrayAsc, true);
            for (int i = 0; i < n; i++)
            {
                string row = "";
                for (int j = 0; j < m; j++)
                {
                    row += sortedArrayAsc[i, j] + " ";
                }
                listBox3.Items.Add(row);
            }

            // Сортируем массив по убыванию и выводим в ListBox2
            listBox2.Items.Clear();
            int[,] sortedArrayDesc = (int[,])array.Clone();
            Sort2DArray(sortedArrayDesc, false);
            ////Array.Sort(sortedArrayDesc, (a, b) => b.CompareTo(a));
            for (int i = 0; i < n; i++)
            {
                string row = "";
                for (int j = 0; j < m; j++)
                {
                    row += sortedArrayDesc[i, j] + " ";
                }
                listBox2.Items.Add(row);
            }
        }
        private void ___TextBox1__TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ___ListBox1__SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ___ListBox2__SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ___ListBox3__SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
