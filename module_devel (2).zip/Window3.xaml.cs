﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace module_devel
{

    public partial class Window3 : Window
    {
        private TextBox textBox;
        private ListBox listBox;
        public Window3()
        {
            InitializeComponent();
            textBox = (TextBox)this.FindName("textBox1");
            listBox = (ListBox)this.FindName("listBox1");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow MainWindow = new MainWindow();
            MainWindow.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Window2 window2 = new Window2();
            window2.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Window4 window4 = new Window4();
            window4.Show();
            this.Close();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Window5 window5 = new Window5();
            window5.Show();
            this.Close();
        }

        private int[] FindMaxProduct(List<int> numbers)
        {
            // Сортируем числа в порядке убывания
            numbers.Sort((a, b) => b.CompareTo(a));

            // Находим максимальное произведение
            int[] result = new int[3];
            if (numbers.Count >= 3)
            {
                result[0] = numbers[0];
                result[1] = numbers[1];
                result[2] = numbers[2];
            }
            else if (numbers.Count == 2)
            {
                result[0] = numbers[0];
                result[1] = numbers[1];
                result[2] = 1;
            }
            else if (numbers.Count == 1)
            {
                result[0] = numbers[0];
                result[1] = 1;
                result[2] = 1;
            }
            else
            {
                result[0] = 0;
                result[1] = 0;
                result[2] = 0;
            }

            return result;
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            // Получаем введенные числа из TextBox
            string[] inputNumbers = textBox.Text.Split(' ');

            // Проверяем, что введено не менее 3 чисел
            if (inputNumbers.Length < 3)
            {
                MessageBox.Show("Необходимо ввести не менее 3 чисел!");
                return; // Прекращаем выполнение, если введено меньше 3 чисел
            }

            // Преобразуем введенные числа в целые числа
            int[] numbers = new int[inputNumbers.Length];
            for (int i = 0; i < inputNumbers.Length; i++)
            {
                if (!int.TryParse(inputNumbers[i], out numbers[i]))
                {
                    MessageBox.Show($"Не удалось преобразовать число: {inputNumbers[i]}");
                    return; // Прекращаем выполнение, если преобразование не удалось
                }
            }

            // Находим три числа, произведение которых максимально
            int[] result = FindMaxProduct(numbers.ToList());

            // Выводим результат в ListBox
            listBox.Items.Add($"Максимальное произведение: {result[0]} * {result[1]} * {result[2]} = {result[0] * result[1] * result[2]}");
        }
    }


}
